import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import { useFonts, Inter_300Light, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold, Inter_900Black } from '@expo-google-fonts/inter';
import 'react-native-gesture-handler';
import GsChatapp from './src/GsChatapp';
import AppState from './src/context/appState';



export default function App() {
  // Load fonts
  let [fontsLoaded, fontError] = useFonts({
    Inter_300Light, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold, Inter_900Black
  });

  if (!fontsLoaded && !fontError) {
    return null;
  }


  return (
    <AppState>
      <View style={ styles.container } >
        <GsChatapp />
        <StatusBar style="auto" />
      </View>
    </AppState>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
});
