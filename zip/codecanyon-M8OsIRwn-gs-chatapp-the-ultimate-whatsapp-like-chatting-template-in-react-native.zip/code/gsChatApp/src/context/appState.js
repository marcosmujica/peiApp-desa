import React from "react";
import AppContext from "./appContext";

const AppState = ({ children }) => {
    const [options, setOptions] = React.useState(false);
    const [alertModal, setAlertModal] = React.useState(false);
    const [alertTitle, setAlertTitle] = React.useState('');
    const [alertDesc, setAlertDesc] = React.useState('');

    const showAlertModal = (title, desc) => {
        setAlertTitle(title);
        setAlertDesc(desc);
        setAlertModal(true);
    }

    return(
        <AppContext.Provider 
            value={{
                options, setOptions,
                alertModal, showAlertModal, setAlertModal,
                alertTitle, alertDesc
            }}
        >
            { children }
        </AppContext.Provider>
    )
}

export default AppState;