import { createStackNavigator } from "@react-navigation/stack";
import BottomTabNavigator from "./BottomTabNavigator";
import * as Screens from '../screens';

const Stack = createStackNavigator();

export const MainStackNavigator = () => {
    return (
        <Stack.Navigator initialRouteName="PreLogin" screenOptions={{ headerShown: false }}>
            <Stack.Screen name="BottomTabNavigator" component={ BottomTabNavigator } />
            <Stack.Screen name="PreLogin" component={ Screens.PreLogin } />
            <Stack.Screen name="Login" component={ Screens.Login } />
            <Stack.Screen name="OTPScreen" component={ Screens.OTPScreen } />
            <Stack.Screen name="AddChat" component={ Screens.AddChat } />
            <Stack.Screen name="NewGroup" component={ Screens.NewGroup } />
            <Stack.Screen name="Group" component={ Screens.Group } />
            <Stack.Screen name="Broadcast" component={ Screens.Broadcast } />
            <Stack.Screen name="Profile" component={ Screens.Profile } />
            <Stack.Screen name="ChatDetails" component={ Screens.ChatDetails } />
            <Stack.Screen name="Calling" component={ Screens.Calling } />
            <Stack.Screen name="AccountSettings" component={ Screens.AccountSettings } />
            <Stack.Screen name="PrivacySettings" component={ Screens.PrivacySettings } />
            <Stack.Screen name="HelpCenter" component={ Screens.HelpCenter } />
            <Stack.Screen name="MyProfile" component={ Screens.MyProfile } />
            <Stack.Screen name="ViewStory" component={ Screens.ViewStory } />
            <Stack.Screen name="AppInfo" component={ Screens.AppInfo } />
            <Stack.Screen name="Information" component={ Screens.Information } />
            <Stack.Screen name="InviteFriend" component={ Screens.InviteFriend } />
        </Stack.Navigator>
    )
}
