import React from 'react';
import { View, Text, TouchableOpacity, Image, FlatList, TextInput, useColorScheme, KeyboardAvoidingView, Platform, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Entypo, AntDesign, Ionicons, FontAwesome, MaterialIcons, Feather } from '@expo/vector-icons';
import {  tStyles, colors } from '../common/theme';
import moment from 'moment';
import { getStyles } from '../styles/chatdetails';
import AppContext from '../context/appContext';
import SlideOptions from '../components/SlideOptions';


const ChatDetails = ({ navigation }) => {
    const mode = useColorScheme();
    const behavior = Platform.OS === 'ios' ? 'height' : 'padding';
    const  {options, setOptions, showAlertModal} = React.useContext(AppContext);


    const links = [
        { id:1, title: "Block Contact", onPress: () => showAlertModal('Block Contact', 'Are you sure you want to block this contact?') },
        { id:2, title: "Clear Chat", onPress: () => showAlertModal('Clear Chat', 'Are you sure you want to clear this conversation?') },
    ];



    const chatData = [
        { id: 1, msg: 'Hey There !!!', time: '2024-07-23T13:13:13.016Z', me: false },
        { id: 2, msg: 'Hello', time: '2024-07-23T13:13:13.016Z', me: true },
        { id: 3, msg: 'How are you?', time: '2024-07-23T13:13:13.016Z', me: true },
        { id: 4, msg: 'I m fine. WBU?', time: '2024-07-23T13:13:13.016Z', me: false },
        { id: 5, msg: 'Great. 😊😊😊😊', time: '2024-07-23T13:13:13.016Z', me: true },
        { id: 6, msg: 'Nice', time: '2024-07-23T13:13:13.016Z', me: false },
        { id: 7, msg: 'Send some pictures', time: '2024-07-23T13:13:13.016Z', me: false },
        { id: 8, msg: 'Sure. Sending right away', time: '2024-07-23T13:13:13.016Z', me: true },
        { id: 9, msg: '', time: '2024-07-23T13:13:13.016Z', me: true, uri: 'https://picsum.photos/id/110/200/300' },
        { id: 10, msg: '', time: '2024-07-23T13:13:13.016Z', me: true, uri: 'https://picsum.photos/id/500/200/300' },
        { id: 11, msg: 'Yeah Absolutely', time: '2024-07-23T13:13:13.016Z', me: true, reply: 6 },
    ];

    return(
        <SafeAreaView edges={[ 'top', 'right', 'left' ]} style={getStyles(mode).container}>
            <KeyboardAvoidingView behavior={ behavior } style={ [ tStyles.flex1 ] }>
                {/* Top Bar  */}
                <View style={ getStyles(mode).topBar }>
                    <View style={[ tStyles.row ]}>
                        <View style={[ tStyles.row ]}>
                            <TouchableOpacity onPress={() => navigation.goBack()}>
                                <AntDesign name="arrowleft" size={ 20 } color={ (mode == 'dark') ? colors.gray30 : null } />
                            </TouchableOpacity>

                            <TouchableOpacity onPress={() => navigation.navigate('Profile')} style={{ marginLeft: 3 }}>
                                <Image
                                    source={{ uri: 'http://i.pravatar.cc/320' }}
                                    style={{ width: 40, height: 40, borderRadius: 25 }}
                                />
                            </TouchableOpacity>
                        </View>
                        
                        

                        <View style={{ marginLeft: 13 }}>
                            <Text style={[ getStyles(mode).topBarMainText ]}>Jason Holder</Text>
                            <Text style={[ getStyles(mode).topBarSecText ]}>last seen today at 4:10 pm</Text>
                        </View>
                    </View>

                    <View style={[ tStyles.row ]}>
                        <TouchableOpacity onPress={() => navigation.navigate('Calling') } style={{ marginRight: 15 }}>
                            <Ionicons name='call-outline' size={ 20 } color={ (mode == 'dark') ? colors.gray30 : null } />
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => setOptions(true)}>
                            <Entypo name='dots-three-vertical' size={ 20 } color={ (mode == 'dark') ? colors.gray30 : null } />
                        </TouchableOpacity>
                    </View>
                </View>





                {/* Chats Listing */}
                <FlatList 
                    showsVerticalScrollIndicator={ false }
                    bounces={ false }
                    data={chatData}
                    keyExtractor={ (item) => item.id }
                    renderItem={ ({item}) => <ChatItem chat={ item } /> } 
                    contentContainerStyle={ getStyles(mode).chatListing }
                />

                
                
                {/* New Chat Input */}
                <View style={getStyles(mode).chatInputHolder}>
                    <View style={ getStyles(mode).chatInput }>
                        <TouchableOpacity>
                            <MaterialIcons name='insert-emoticon' size={ 20 } color={ (mode == 'dark') ? colors.gray30 : null } />
                        </TouchableOpacity>

                        <TextInput
                            placeholder='Message'
                            style={ getStyles(mode).chatInputText }
                            placeholderTextColor={ (mode == 'dark') ? colors.gray30 : null }
                        />

                        <TouchableOpacity>
                            <Feather name='camera' size={ 20 } color={ (mode == 'dark') ? colors.gray30 : null } />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity style={getStyles(mode).sendBtn}>
                        <FontAwesome name="send" size={ 20 } />
                    </TouchableOpacity>
                </View>

                {/* Slide Options */}
                { options && <SlideOptions links={ links } setOptions={ setOptions } />}

            </KeyboardAvoidingView>
        </SafeAreaView>
        
    )
}


const ChatItem = ({ chat }) => {
    const mode = useColorScheme();
    const { width } = useWindowDimensions();

    return(
        <View>
            <View style={[ getStyles(mode).chatBubble, (chat.me) ? getStyles(mode).chatBubbleMe : null ]}>
                { 
                    (chat.uri) 
                    &&
                    <Image
                        source={{ uri: chat.uri }}
                        style={{ width: (0.6*width), minHeight: 200, borderRadius: 10 }}
                        resizeMode='cover'
                    />
                }

                {
                    (chat.reply)
                    &&
                    <View style={getStyles(mode).replyContainer}>
                        <Text style={getStyles(mode).replyUser}>Jason Holder</Text>
                        <Text style={getStyles(mode).replyMessage}>Nice</Text>
                    </View>
                }

                {(!chat.uri) && <Text style={ getStyles(mode).chatText }>{ chat.msg }</Text>}

                <View style={[ tStyles.row, tStyles.endx, {marginTop: 3} ]}>
                    <Text style={[ getStyles(mode).chatTime ]}>{ moment(chat.time).format('hh:mm a') }</Text>
                    { (chat.me) && <Ionicons name='checkmark-done-sharp' size={ 12 } color={ colors.seen } style={{ marginLeft: 3 }} />}
                </View>
                
            </View>
        </View>
    )
}




export default ChatDetails;