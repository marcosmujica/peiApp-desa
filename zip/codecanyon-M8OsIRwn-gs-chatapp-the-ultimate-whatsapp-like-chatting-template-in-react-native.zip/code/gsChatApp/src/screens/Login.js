import React from 'react';
import { View,Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import CountryCodeDropdownPicker from 'react-native-dropdown-country-picker'
import { colors, fonts, tStyles } from '../common/theme';

const Login = ({ navigation }) => {
    const [selected, setSelected] = React.useState('+91');
    const [country, setCountry] = React.useState('');
    const [phone, setPhone] = React.useState('');

    return(
        <SafeAreaView style={[ tStyles.flex1, { backgroundColor: colors.white } ]}>
            <KeyboardAvoidingView behavior='padding' style={[ tStyles.flex1 ]}>
                <View style={[ tStyles.centery, { paddingVertical: 15 } ]}>
                    <Text style={[ fonts.semibold, { fontSize: 15, color: colors.primary } ]}>Enter your phone number</Text>
                </View>

                <View style={{ paddingHorizontal: 35, marginTop: 20 }}>
                    <Text style={[ fonts.regular, { textAlign: 'center', fontSize: 13 } ]}>ChatApp will need to verify your number. Carrier charges may apply.</Text>
                </View>

                
                {/* Country Picker */}
                <View style={[ tStyles.flex1, { marginTop: 30, paddingHorizontal: 15 }]}>
                    <Text style={[ fonts.bold, { fontSize: 17, textAlign: 'center', marginBottom: 10 } ]}>{ country.name }</Text>
                    <CountryCodeDropdownPicker 
                        selected={selected} 
                        setSelected={setSelected}
                        setCountryDetails={setCountry} 
                        phone={phone} 
                        setPhone={setPhone} 
                        phoneStyles={{ height: 40 }}
                        countryCodeTextStyles={{fontSize: 13, ...fonts.regular}}
                        dropdownTextStyles={{fontSize: 13, ...fonts.semibold, fontWeight: 'normal'}}
                    />
                </View>


                {/* Agree Button */}
                <View style={{ paddingHorizontal: 15, marginBottom: 15 }}>
                    <TouchableOpacity onPress={() => navigation.navigate('OTPScreen')} style={ styles.agreeBtn }>
                        <Text style={[ fonts.medium, { color: colors.white, fontSize: 13 }  ]}>Next</Text>
                    </TouchableOpacity>
                </View>

            </KeyboardAvoidingView>
            
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    agreeBtn: {
        width: '100%',
        backgroundColor: colors.primary,
        ...tStyles.centery,
        paddingVertical: 12,
        borderRadius: 30
    }
})

export default Login;