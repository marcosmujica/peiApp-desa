import React from 'react';
import { View,Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import OtpTextInput from 'react-native-text-input-otp'
import { colors, fonts, tStyles } from '../common/theme';

const OTPScreen = ({ navigation }) => {
    const [otp, setOtp] = React.useState('');

    return(
        <SafeAreaView style={[ tStyles.flex1, { backgroundColor: colors.white } ]}>
            <KeyboardAvoidingView behavior='padding' style={[ tStyles.flex1 ]}>
                <View style={[ tStyles.centery, { paddingVertical: 15 } ]}>
                    <Text style={[ fonts.semibold, { fontSize: 15, color: colors.primary } ]}>Verifying your number</Text>
                </View>

                <View style={{ paddingHorizontal: 35, marginTop: 20 }}>
                    <Text style={[ fonts.regular, { textAlign: 'center', fontSize: 13 } ]}>Waiting to automatically detect an SMS sent to</Text>
                    <Text style={[ fonts.semibold, { textAlign: 'center', fontSize: 13, marginTop: 4 } ]}>+91 9857621525. <Text style={[ fonts.regular, { color: '#0096FF' }]}>Wrong number?</Text></Text>
                </View>


                {/* OTP Input */}
                <View style={[ tStyles.flex1, tStyles.centery, { paddingHorizontal: 40, marginTop: 40 } ]}>
                    <OtpTextInput 
                        otp={ otp }
                        setOtp={ setOtp }
                        digits={6} 
                        style={{ borderTopWidth: 0, borderRightWidth: 0, borderLeftWidth: 0, borderRadius: 0 }}
                        fontStyle={{ ...fonts.black, color: colors.gray75, fontSize: 18 }}
                    />

                    <View style={[ tStyles.centery, { marginTop: 40 } ]}>
                        <TouchableOpacity>
                            <Text style={[ fonts.semibold, { color: colors.primary } ]}>Didn't receive code?</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            

        
                {/* Agree Button */}
                <View style={{ paddingHorizontal: 15, marginBottom: 15 }}>
                    <TouchableOpacity onPress={() => navigation.navigate('BottomTabNavigator')} style={ styles.agreeBtn }>
                        <Text style={[ fonts.medium, { color: colors.white, fontSize: 13 }  ]}>Login</Text>
                    </TouchableOpacity>
                </View>

            </KeyboardAvoidingView>

            
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    agreeBtn: {
        width: '100%',
        backgroundColor: colors.primary,
        ...tStyles.centery,
        paddingVertical: 12,
        borderRadius: 30
    }
})

export default OTPScreen;