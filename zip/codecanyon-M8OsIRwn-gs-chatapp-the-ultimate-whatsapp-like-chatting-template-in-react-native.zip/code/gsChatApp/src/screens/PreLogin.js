import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import LottieView from 'lottie-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, fonts, tStyles } from '../common/theme';

const PreLogin = ({ navigation }) => {
    return(
        <SafeAreaView style={[ tStyles.flex1, { backgroundColor: colors.white }]}>
            <View style={[ tStyles.centery, { marginTop: 30 } ]}>
                <LottieView 
                    source={ require('../assets/animations/prelogin.json') }
                    style={{ width: '100%', height: 300 }}
                    autoPlay={ true }
                />
            </View>


            <View style={[ tStyles.centery, tStyles.flex1, { paddingHorizontal: 15 } ]}>
                <Text style={[ fonts.medium, { fontSize: 22, marginBottom: 15 } ]}>Welcome to GS ChatApp</Text>
                <Text style={[fonts.regular, { fontSize: 12, textAlign: 'center', lineHeight: 18, color: colors.gray50 }]}>
                    Read our <Text style={{ color: '#0096FF' }}>Privacy Ploicy.</Text> Tap "Agree & continue" to accept the 
                    <Text style={{ color: '#0096FF' }}> Terms of Service.</Text>
                </Text>
            </View>


            {/* Agree Button */}
            <View style={{ paddingHorizontal: 15, marginBottom: 15 }}>
                <TouchableOpacity onPress={() => navigation.navigate('Login')} style={ styles.agreeBtn }>
                    <Text style={[ fonts.medium, { color: colors.white, fontSize: 13 }  ]}>Agree and continue</Text>
                </TouchableOpacity>
            </View>
            
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    agreeBtn: {
        width: '100%',
        backgroundColor: colors.primary,
        ...tStyles.centery,
        paddingVertical: 12,
        borderRadius: 30
    }
})

export default PreLogin;